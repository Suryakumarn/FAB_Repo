package OfsString;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentReport {


	public static void Write_Result(String result_path, String Status ,String customerID ,String Functionality,String Business_Flow,String Dtime,String Expected_Result,String Business_Rule,String output){
		ExtentReports Report = new ExtentReports(result_path.replace("Detailed_Report","Extent_Report").replace(".xlsx", ".html"),false);
		//System.out.println("Extent Report TestName" + OfsStringMethods.globalval.get("TestCase").toString());
		
		ExtentTest Logger = Report.startTest(OfsStringMethods.globalval.get("TestCase").toString());
		if (Status == "Pass"){
			Logger.log(LogStatus.PASS, "Log Description:"
					+ "<br>"
					+ "<br>"
					+ "<b>Functionality : </b>" + OfsStringMethods.globalval.get("Functionality").toString()
					+ "<br>"
					+ "<b>Business_Rule : </b>" + Business_Rule
					+ "<br>"
					+ "<b>Expected_Result : </b>" + Expected_Result
					+ "<br>"
					+ "<b>Business_Flow : </b>" + Business_Flow
					+ "<br>"
					+"<b>OutputId : </b>" + customerID
					+ "<br>"
					+ "<b>ReferenceId : </b>" + output
					+ "<br>"
					+ "<b>Output Remarks : </b>" + Functionality
					+ "<br>"
					+ "<b>Transaction Start Time : </b>" + Dtime
					+ "<br>"
					);	
		}else{
			Logger.log(LogStatus.FAIL, "Log Description:"
					+ "<br>"
					+ "<br>"
					+ "<b>Functionality : </b>" + OfsStringMethods.globalval.get("Functionality").toString()
					+ "<br>"
					+ "<b>Business_Rule : </b>" + Business_Rule
					+ "<br>"
					+ "<b>Expected_Result : </b>" + Expected_Result
					+ "<br>"
					+ "<b>Business_Flow : </b>" + Business_Flow
					+ "<br>"
					+"<b>OutputId : </b>" + customerID
					+ "<br>"
					+ "<b>ReferenceId : </b>" + output
					+ "<br>"
					+ "<b>Output Remarks : </b>" + Functionality
					+ "<br>"
					+ "<b>Transaction Start Time : </b>" + Dtime
					+ "<br>"
					);			
		}
		
		Report.endTest(Logger);
		Report.flush();Report.close();
	}
}
