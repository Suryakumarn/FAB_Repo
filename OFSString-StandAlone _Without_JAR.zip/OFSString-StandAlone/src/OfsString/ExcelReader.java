package OfsString;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import javax.swing.text.Utilities;

import java.util.Calendar;

import org.apache.bcel.classfile.Utility;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import au.com.bytecode.opencsv.CSVReader;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.*;

import com.maveric.Data.DataProvider;
import com.maveric.DataHolder.FinalTestDataHolderClass;

public class ExcelReader {
	static HashMap g_globalval = new HashMap(); 
	static String dp = System.getProperty("user.dir");
	
	public static String now(String dateFormat) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		return sdf.format(cal.getTime());
	} 
	
	
		public static String FolderCreate(String args) {
				String fdname_fullpath = args;
				File f = new File(fdname_fullpath);
				try {
					if (f.exists() == false) {
						f.mkdir();
						
					} else {
						
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return fdname_fullpath;
			} 

		public static void copyFile(String sourcePath, String destinationPath)
					 {
				
				try {
					File source = new File(sourcePath);
					File destination = new File(destinationPath);

					if (destination.isDirectory())
						destination = new File(destination, source.getName());

					FileInputStream input = new FileInputStream(source);
					copy_File(input, destination);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} 
		
		
			public static void copy_File(InputStream input, File destination)
						throws IOException {
					OutputStream output = null;

					output = new FileOutputStream(destination);

					byte[] buffer = new byte[1024];

					int bytesRead = input.read(buffer);

					while (bytesRead >= 0) {
						output.write(buffer, 0, bytesRead);
						bytesRead = input.read(buffer);
					}

					input.close();

					output.close();
				} 

			public static void Write_Reult(String sourcePath,String status1,String status2,String status5,String status3,String status4
					,String status6,String status7,String status8) throws  FilloException{
				
				String str7= status7;
				String str6= status6;
				String str5= status5;
				//chabjh
				Fillo fillo=new Fillo();
				Connection connection=fillo.getConnection(sourcePath);
				//TRUNCATE TABLE employee; 
				if (status6.contains("'")){
					str6 = status6.replace("'", "");
				}
				if (status5.contains("'")){
					str5 = status5.replace("'", "");
				}
				if (status7.contains("'")){
					str7 = status7.replace("'", "");
				}
				String strQuery ="INSERT INTO Results (Functionality,TestCase,Business_Rule,Expected_Result,Business_flow,Status,Output_ID,Reference_ID,Output_Remarks,Start_Time)"
						+"VALUES ('"+OfsStringMethods.globalval.get("Functionality").toString()+"','"+OfsStringMethods.globalval.get("TestCase").toString()+"','"
						+str7+"','"+str6+"','"+status3+ "','"+status1+ "','"+status2+ "','"+status8+"','"
						+str5+ "','"+"BST:"+status4+"')";
				
				//System.setProperty("TC",OfsStringMethods.globalval.get("TestCase").toString() );
				//System.setProperty("Functiona",OfsStringMethods.globalval.get("Functionality").toString());
				
				System.out.println(OfsStringMethods.globalval.get("TestCase").toString() + " <--> " + OfsStringMethods.globalval.get("Functionality").toString()+ " <--> " +status1 );
				
				connection.executeUpdate(strQuery);
				connection.close();
				            
			}
			
			public static void Write_Reultnew(String sourcePath,String status1,String status2,String status5,String status3,String status4
					,String status6,String status7,String status8,String status9) throws  FilloException{
				
				String str7= status7;
				String str6= status6;
				String str5= status5;
				//chabjh
				Fillo fillo=new Fillo();
				Connection connection=fillo.getConnection(sourcePath);
				//TRUNCATE TABLE employee; 
				if (status6.contains("'")){
					str6 = status6.replace("'", "");
				}
				if (status5.contains("'")){
					str5 = status5.replace("'", "");
				}
				if (status7.contains("'")){
					str7 = status7.replace("'", "");
				}
				String strQuery ="INSERT INTO Results (Functionality,TestCase,Business_Rule,Expected_Result,Business_flow,Status,Output_ID,Reference_ID,Output_Remarks,Start_Time,Expected_Output)"
						+"VALUES ('"+OfsStringMethods.globalval.get("Functionality").toString()+"','"+OfsStringMethods.globalval.get("TestCase").toString()+"','"
						+str7+"','"+str6+"','"+status3+ "','"+status1+ "','"+status2+ "','"+status8+"','"
						+str5+ "','"+"BST:"+status4+"','"+status9+"')";
				
				System.out.println(OfsStringMethods.globalval.get("TestCase").toString() + " <--> " + OfsStringMethods.globalval.get("Functionality").toString()+ " <--> " +status1 );
				
				connection.executeUpdate(strQuery);
				connection.close();
				            
			}
			
			public static void Write_Reult1(String sourcePath,String status1,String status2,String status5,String status3,String status4
						,String status6,String status7,String status8) throws EncryptedDocumentException, InvalidFormatException,IOException{
			try {
				//ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",output[0].substring(5,output[0].length()),"Not able to create the Account number",singleentry.get("CaseType"),Dtime,singleentry.get("Expected Result"));
				Workbook file;
				file = WorkbookFactory.create(new FileInputStream(sourcePath));
				Sheet sheet = file.getSheet("Results");
				Cell cell1 = null;
				Cell cell2 = null;
				Cell cell3 = null;
				Cell cell4 = null;
				Cell cell5 = null;
				Cell cell6 = null;
				Cell cell7 = null;
				Cell cell8 = null;
				Cell cell9 = null;
				Cell cell10 = null;
				
				//Update the value of cell
				for (int row=2;row<=10000;row++){
				cell1 = sheet.getRow(row).getCell(0);
				cell2 = sheet.getRow(row).getCell(1);
				cell3 = sheet.getRow(row).getCell(2);
				cell4 = sheet.getRow(row).getCell(3);
				cell5 = sheet.getRow(row).getCell(4);
				cell6 = sheet.getRow(row).getCell(5);
				cell7 = sheet.getRow(row).getCell(6);
				cell8 = sheet.getRow(row).getCell(7);
				cell9 = sheet.getRow(row).getCell(8);
				cell10= sheet.getRow(row).getCell(9);
					
				System.out.println(cell1.getStringCellValue());
				if(cell1.getStringCellValue().trim().length()<=0){
					cell1.setCellValue(OfsStringMethods.globalval.get("Functionality").toString());
					cell2.setCellValue(OfsStringMethods.globalval.get("TestCase").toString());
					cell3.setCellValue(status7);
					cell4.setCellValue(status6);
					cell5.setCellValue(status3);
					cell6.setCellValue(status1);
					cell7.setCellValue("'" + status2);
					cell8.setCellValue(status8);
					cell9.setCellValue(status5);
					cell10.setCellValue("BST:" + status4);
					System.out.println(cell2.getStringCellValue() + " <--> " + cell1.getStringCellValue() + " <--> " +cell6.getStringCellValue() );
					break;
				}
			
				}			
				FileOutputStream outFile =new FileOutputStream(new File(sourcePath));
				file.write(outFile);
				outFile.close();
				
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			}
			
		public static String report_folder(String module, String datasheet){
			try{
			
				String cur_date = now("dd")+"_"+ now("MM")+"_"+ now("YYYY");
				String cur_time = now("hh")+"_"+ now("mm")+"_"+ now("ss");
				
				String detailedreport = dp + "\\Results\\Detailed_Report\\";
				FolderCreate(detailedreport);
				
				g_globalval.put("Result_Folder_Date",dp+"\\Results\\Detailed_Report\\"+module);	
				String folder_results_date = (String) g_globalval.get("Result_Folder_Date");
				FolderCreate(folder_results_date);
				
				String modulename = folder_results_date+ "\\" + datasheet;
				FolderCreate(modulename);
				
				String template_Result = dp+"\\Templates\\Execution_Report.xlsx";
				g_globalval.put("Result_File",modulename+"\\"+datasheet+"_"+cur_date+"_"+cur_time+".xlsx");
	
				copyFile(template_Result,g_globalval.get("Result_File").toString());
				
			} catch (Exception E) {
				E.printStackTrace();
				System.out.println(E.getMessage());
			}
			return g_globalval.get("Result_File").toString();
		}
			
	public static ArrayList<LinkedHashMap<String, String>> readScenarioSheet(
			String runFile) {
		try {
			
			Workbook file;
			file = WorkbookFactory.create(new FileInputStream(runFile));
			Sheet sheet = file.getSheet("ScenariosPicker");
			List<String> labelnames = new ArrayList<String>();
			LinkedHashMap<String, Integer> indextemplate = new LinkedHashMap<String, Integer>();
			ArrayList<LinkedHashMap<String, Integer>> datacomb = new ArrayList<LinkedHashMap<String, Integer>>();
			String itcr = ProjectConfig.getPropertyValue("itcrnumber");
			//System.out.println("Fetching Scenarios for " + itcr + " ITCR");
			for (Row row : sheet) {
				Cell firstcell = row.getCell(0);
				String label = firstcell.getStringCellValue();
				switch (label) {
				case "TEST-Indicator":

					for (Cell cell : row) {
						int column_index = cell.getColumnIndex();
						String column_name = cell.getStringCellValue();
						labelnames.add(column_name);
						indextemplate.put(column_name, column_index);
					}
					break;
				case "TEST":
					int runindex = indextemplate.get("Run");
					int itcrindex = indextemplate.get("ITCR_Control");
					
					if (row.getCell(runindex).getStringCellValue()
							.equalsIgnoreCase("YES") & row.getCell(itcrindex).getStringCellValue().contains(itcr) ) {
						LinkedHashMap<String, Integer> indexdata = new LinkedHashMap<String, Integer>();
						for (Cell cell : row) {

							int column_index = cell.getColumnIndex();
							String column_name = cell.getStringCellValue();
							labelnames.add(column_name);
							indexdata.put(column_name, column_index);
						}
						datacomb.add(indexdata);
						// indexdata.clear();
					}
					else if (row.getCell(runindex).getStringCellValue()
							.equalsIgnoreCase("YES") & row.getCell(itcrindex).getStringCellValue().isEmpty() ){
						LinkedHashMap<String, Integer> indexdata = new LinkedHashMap<String, Integer>();
						for (Cell cell : row) {

							int column_index = cell.getColumnIndex();
							String column_name = cell.getStringCellValue();
							labelnames.add(column_name);
							indexdata.put(column_name, column_index);
						}
						datacomb.add(indexdata);
						// indexdata.clear();
					}
					break;
				}

			}
			ArrayList<LinkedHashMap<String, String>> resultcomb = new ArrayList<LinkedHashMap<String, String>>();

			for (LinkedHashMap<String, Integer> comb : datacomb) {
				LinkedHashMap<String, String> dataentry = new LinkedHashMap<String, String>();
				for (Entry<String, Integer> t : indextemplate.entrySet()) {
					for (Entry<String, Integer> c : comb.entrySet()) {
						if (t.getValue() == c.getValue()) {
							dataentry.put(t.getKey(), c.getKey());
						}
					}
				}
				resultcomb.add(dataentry);
			}
			System.out.println(resultcomb);
			return resultcomb;
		} catch (Exception E) {
			E.printStackTrace();
			System.out.println(E.getMessage());
		}
		return null;
	}
	
	//To store output in the database
	public static void storeoutput(String sourcePath,String status1,String status2,String status3) throws  FilloException{
	
		Fillo fillo=new Fillo();
		String strQuery = null;
		Connection connection=fillo.getConnection(sourcePath);
		String sstrQuery="Select * from OutputValues where ScenarioVariables='"+status1+"'";
		
		try{
			Recordset recordset=((com.codoid.products.fillo.Connection) connection).executeQuery(sstrQuery);
			strQuery="Update OutputValues Set TransactionID='"+status2+"', ReferenceID='"+status3+"' WHERE ScenarioVariables='"+status1+"'";
			recordset.close();
		}
		
		catch (Exception exc){
			String eror = exc.getMessage();
			if (eror.equalsIgnoreCase("No records found")){
				strQuery ="INSERT INTO OutputValues (ScenarioVariables,TransactionID,ReferenceID)"
						+"VALUES ('"+status1+"','"+status2+"','"+status3+"')";
			}
		}
		
		connection.executeUpdate(strQuery);
		connection.close();
	}
	
	//To fetch the output from database
	public static String fetchoutput(String sourcePath,String status1) throws  FilloException{
		
		Fillo fillo=new Fillo();
		Connection connection=fillo.getConnection(sourcePath);
		String val = null;
		
		String strQuery="Select TransactionID from OutputValues where ScenarioVariables='"+status1+"'";
		Recordset recordset=((com.codoid.products.fillo.Connection) connection).executeQuery(strQuery);
		while(recordset.next()){
			val = recordset.getField("TransactionID");
		}
		
		recordset.close();
		connection.close();
		return val;
	}
	
	//To clear the output values in the database
	public static void clearOutput(String sourcePath) throws  FilloException{
		
		Fillo fillo=new Fillo();
		Connection connection=fillo.getConnection(sourcePath);
		 
		String strQuery =" DELETE FROM OutputValues ";

		connection.executeUpdate(strQuery);
		connection.close();
	}
	
	public static String fetchoutput1(String sourcePath,String status1) throws  FilloException{
		
		Fillo fillo=new Fillo();
		Connection connection=fillo.getConnection(sourcePath);
		String val = null;
		
		String strQuery="Select TransactionID from OutputValues where ScenarioVariables='"+status1+"'";
		Recordset recordset=((com.codoid.products.fillo.Connection) connection).executeQuery(strQuery);
		while(recordset.next()){
			val = recordset.getField("TransactionID");
		}
		
		recordset.close();
		connection.close();
		return val;
	}

	public static ArrayList<LinkedHashMap<String, String>> readDataFormat(
			String testCase, String configfile, String sheetname) {
		try {
			Workbook file;
			file = WorkbookFactory.create(new FileInputStream(configfile));
			Sheet sheet = file.getSheet(sheetname);
			LinkedHashMap<Integer, String> indextemplate = new LinkedHashMap<Integer, String>();
			ArrayList<LinkedHashMap<Integer, String>> datacomb = new ArrayList<LinkedHashMap<Integer, String>>();

			for (Row row : sheet) {
				Cell firstcell = row.getCell(0);
				//System.out.println(firstcell);
				String label = firstcell.getStringCellValue();
				//System.out.println(row.getCell(3).getStringCellValue());
				//String flowversion = row.getCell(6).getStringCellValue();
				switch (label) {
				case "DataBinding":
					for (Cell cell : row) {
						int column_index = cell.getColumnIndex();
						String column_name = cell.getStringCellValue();
						indextemplate.put(column_index, column_name);
					}
					break;
				default:
					if (label.equalsIgnoreCase(testCase)  ) {
						//&& flowversion.equalsIgnoreCase("xyz")
						LinkedHashMap<Integer, String> indexdata = new LinkedHashMap<Integer, String>();
						for (Cell cell : row) {
							int column_index = cell.getColumnIndex();
							//System.out.println(cell.getStringCellValue());
							String column_name = cell.getStringCellValue();
							indexdata.put(column_index, column_name);
						}
						datacomb.add(indexdata);
					}
					break;
				}
			}
			ArrayList<LinkedHashMap<String, String>> resultcomb = new ArrayList<LinkedHashMap<String, String>>();

			for (LinkedHashMap<Integer, String> comb : datacomb) {
				LinkedHashMap<String, String> dataentry = new LinkedHashMap<String, String>();
				for (Entry<Integer, String> t : indextemplate.entrySet()) {
					for (Entry<Integer, String> c : comb.entrySet()) {
						if (t.getKey() == c.getKey()) {
							dataentry.put(t.getValue(), c.getValue());
						}
					}
				}
				resultcomb.add(dataentry);
			}
			System.out.println(resultcomb);
			return resultcomb;
		} catch (Exception E) {
			E.printStackTrace();
			System.out.println(E.getMessage());
		}
		return null;
	}

	public static String fetchoutput_DataBase(String fileName,String sheetName) throws  FilloException{	
		g_globalval.put("ExtractedFileName",fileName);
		g_globalval.put("ExtractedSheetName",sheetName);
		Fillo fillo=new Fillo();
		String path = dp + "//ExtractedData//" + fileName;
		Connection connection=fillo.getConnection(path);
		String id = null;		
		String strQuery="Select ID from "+sheetName+" where Control<>'Y'";
		Recordset recordset=((com.codoid.products.fillo.Connection) connection).executeQuery(strQuery);
		while(recordset.next()){
			id = recordset.getField("ID");
			//String strQuery2="Update "+sheetName+" Set Control='Y'WHERE ID='"+id+"'";
			//connection.executeUpdate(strQuery2);
			break;
		}
		recordset.close();
		connection.close();
		return id;
	}

	public static void update_extracted_output(String id, String fileName,String sheetName) throws FilloException {
		Fillo fillo=new Fillo();
		String path = dp + "//ExtractedData//" + fileName;		
		Connection connection=fillo.getConnection(path);		
		String strQuery2="Update "+sheetName+" Set Control='Y'WHERE ID='"+id+"'";
		connection.executeUpdate(strQuery2);
		connection.close();
	}
	
	public static String[] fetchFileAndSheetName(String sourcePath,String scenarioVariables) throws  FilloException{
		
		Fillo fillo=new Fillo();
		Connection connection=fillo.getConnection(sourcePath);
		String fileName = null;
		String sheetName = null;
		String[] fileNamesheetName = new String [2];
		
		
		String strQuery="Select * from OutputValues where ScenarioVariables='"+scenarioVariables+"'";
		Recordset recordset=((com.codoid.products.fillo.Connection) connection).executeQuery(strQuery);
		while(recordset.next()){
			fileName = recordset.getField("FileName");
			sheetName = recordset.getField("SheetName");
		}
		fileNamesheetName[0] = fileName;
		fileNamesheetName[1] = sheetName;
		recordset.close();
		connection.close();
		return fileNamesheetName;
	}
	
	public static String[] masterreport(String sourcePath,String submodpath,String execution_mode,String Module,String submodule) throws  FilloException{
		    
			Fillo fillo=new Fillo();
			Connection connection=fillo.getConnection(g_globalval.get("MResult_File").toString());
			Connection connection1=fillo.getConnection(submodpath);
		    
			String strQuery1="Select COUNT(DISTINCT Status) from Results";
			String strQuery="Select COUNT(DISTINCT Status) from Results Where Status = 'Pass'";
			
			
			Recordset recordset1=((com.codoid.products.fillo.Connection) connection1).executeQuery(strQuery1);
			Recordset recordset=((com.codoid.products.fillo.Connection) connection1).executeQuery(strQuery);
			int failcount = recordset1.getCount() - recordset.getCount();
			
			strQuery ="INSERT INTO Report (Module,Sub_Module,ExecutionMode,Case_Count,Pass,Fail)"
					+"VALUES ('"+Module+"','"+submodule+"','"+execution_mode+"','"+recordset1.getCount()+"','"+recordset.getCount()+"','"+failcount+"')";
			
			connection.executeUpdate(strQuery);			
	
			recordset.close();
			connection.close();
			
			recordset1.close();
			connection1.close();
			return null;
			
		}

	public static String masterfolder(String sourcePath){
		
		FolderCreate(dp+"\\Results\\"+"Master_Report");
		
		g_globalval.put("MResult_File",dp+"\\Results\\"+"Master_Report\\"+"Master_Report_"+now("dd")+"_"+ now("MM")+"_"+ now("YYYY")+"_"+now("hh")+"_"+ now("mm")+"_"+ now("ss")+".xlsx");
		copyFile(sourcePath,g_globalval.get("MResult_File").toString());
		
	return null;
	
	}
	
	//--------------- Dynamic input verification begin
    public static void write_output_xl(String sourcePath) throws Exception{
	  Workbook wb = new XSSFWorkbook();
	  Sheet sheet = wb.createSheet("output");
      CSVReader reader = new CSVReader(new FileReader(System.getProperty("user.dir")+"//outputfile//output.csv"));
      String[] line;
      int r  = 0 ;
      while ((line = reader.readNext()) != null) {
        Row row = sheet.createRow((short) r++);
        for (int i = 0; i < line.length; i++)
        if(i < 4){
          row.createCell(i).setCellValue(line[i].toString());
	    }
       }
       FileOutputStream fileOut = new FileOutputStream(sourcePath);
	   wb.write(fileOut);
	   fileOut.close();
	}
	
	public static void Write_input(String sourcePath,String sheetname) throws Exception{
	  try {
		DataProvider dpr = new DataProvider();
		ArrayList<FinalTestDataHolderClass> fdc=new  ArrayList<FinalTestDataHolderClass>();
		fdc = dpr.handler();
		write_output_xl(sourcePath);
		Workbook file;		
		file = WorkbookFactory.create(new FileInputStream(sourcePath));
		Sheet sheet = file.getSheet(sheetname);
		String td1 = null;
		int row = 0;
		for(FinalTestDataHolderClass fc:fdc){
			row++;
			if(fc.getValue().length()>0){
				td1=fc.getValue();
			}else{
				td1= "";
			}
			Cell cell2Update = sheet.getRow(row).getCell(3);
			cell2Update.setCellValue(td1);			
		}
		FileOutputStream outFile =new FileOutputStream(new File(sourcePath));
		file.write(outFile);
		outFile.close();		
	  } catch (FileNotFoundException e) {
		e.printStackTrace();
	  } catch (IOException e) {
		e.printStackTrace();
	  }
	}
	
	public static ArrayList<LinkedHashMap<String, String>> readOutputSheet(String outputFile,String Combination) throws EncryptedDocumentException, InvalidFormatException, FileNotFoundException, IOException{
		Workbook file;
		file = WorkbookFactory.create(new FileInputStream(outputFile));
		Sheet sheet = file.getSheet("output");
		List<String> labelnames = new ArrayList<String>();
		LinkedHashMap<String, Integer> indextemplate = new LinkedHashMap<String, Integer>();
		ArrayList<LinkedHashMap<String, Integer>> datacomb = new ArrayList<LinkedHashMap<String, Integer>>();
		
		for (Row row : sheet) {
			Cell firstcell = row.getCell(0);
			String label = firstcell.getStringCellValue();
			if (label.equalsIgnoreCase("Field name")) {			
				for (Cell cell : row) {
					int column_index = cell.getColumnIndex();
					String column_name = cell.getStringCellValue();
					labelnames.add(column_name);
					indextemplate.put(column_name, column_index);
				}
			}else if (label.equalsIgnoreCase(Combination)){
				int runindex = indextemplate.get("Field name");
				if(row.getCell(runindex).getStringCellValue().equalsIgnoreCase(Combination)){
					LinkedHashMap<String, Integer> indexdata = new LinkedHashMap<String, Integer>();					
					for (Cell cell : row) {
			  		  int column_index = cell.getColumnIndex();
					  String column_name = cell.getStringCellValue();
					  labelnames.add(column_name);
					  indexdata.put(column_name, column_index);
				    }
				    datacomb.add(indexdata);
			    }
			}
		}
		ArrayList<LinkedHashMap<String, String>> resultcomb = new ArrayList<LinkedHashMap<String, String>>();

		for (LinkedHashMap<String, Integer> comb : datacomb) {
			LinkedHashMap<String, String> dataentry = new LinkedHashMap<String, String>();
			for (Entry<String, Integer> t : indextemplate.entrySet()) {
				for (Entry<String, Integer> c : comb.entrySet()) {
					if (t.getValue() == c.getValue()) {
						dataentry.put(t.getKey(), c.getKey());
					}
				}
			}
			resultcomb.add(dataentry);
		}		
		return resultcomb;
		}
	// Dynamic payment input ends
}
