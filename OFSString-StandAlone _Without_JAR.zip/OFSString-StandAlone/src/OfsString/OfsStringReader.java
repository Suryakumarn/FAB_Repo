package OfsString;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.SkipException;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class OfsStringReader {

	public static String propertyfile;	
	public static String init(){
		String storeFile = System.getProperty("user.dir")+"//resources//OutputData.xlsx";
		return storeFile;
	}
	
	public static void main(String[] args) throws Exception {		
		System.out.println("START TIME: " + CommonDef.currDate());		
		String runFile = System.getProperty("user.dir")+"//resources//ScenarioSheet.xlsx";
		String runConfig = System.getProperty("user.dir")+"//resources//OfsStringData.xlsx";
		propertyfile = System.getProperty("user.dir")+"//resources//ProjectConfig.properties";
		String masterpath = System.getProperty("user.dir")+"//Templates//Master_Report.xlsx";
		ArrayList<LinkedHashMap<String, String>> testset = ExcelReader
				.readScenarioSheet(runFile);
		
		try {
			Session sshsession = CommonDef.sessionOpen();
			sshsession.setTimeout(100);
			
			Channel channel;
			channel = OfsStringMethods.establishChannelAsShell(sshsession);
			int loop;
			
			ExcelReader.masterfolder(masterpath);
			
			for (LinkedHashMap<String, String> test : testset) {
				String testcase = test.get("ScenarioID");
				String datasheet = test.get("DataSheet");
				String module = test.get("Module");
				String execution_mode = test.get("ExecutionMode");				
				String[] sht = null;
				String submod_path = ExcelReader.report_folder(module,datasheet);
				
					if (datasheet.contains(",")){
						sht = datasheet.split(",");
						for (loop=0;loop<=sht.length-1;loop++){
							String ofsdata = OfsStringMethods.create_Account(channel, testcase,
									runConfig,sht[loop],sshsession,execution_mode);
							}
					}else {
							String ofsdata = OfsStringMethods.create_Account(channel, testcase,
									runConfig,datasheet,sshsession,execution_mode);
					}
					
					ExcelReader.masterreport(masterpath, submod_path , execution_mode, module , datasheet );
				}
			
			CommonDef.sessionClose(sshsession);
			
		} catch (JSchException e) {
			e.printStackTrace();
		}
		System.out.println("END TIME: " + CommonDef.currDate());		
	}
	
}
