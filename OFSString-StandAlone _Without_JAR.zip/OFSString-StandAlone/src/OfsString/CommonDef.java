package OfsString;

import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.UIKeyboardInteractive;
import com.jcraft.jsch.UserInfo;

public class CommonDef {

	/**Test
	 * Creates a new JSch Session
	 * 
	 * @return Session established
	 */
	public static Session sessionOpen() {
		try {
			JSch jsch = new JSch();
			String host = ProjectConfig.getPropertyValue("sesshost");
			System.out.println("HOST " + host);
			String user = ProjectConfig.getPropertyValue("sessuser");
			Session session = jsch.getSession(user, host, 22);
			session.setPassword(ProjectConfig.getPropertyValue("sesspass"));
			session.setConfig("StrictHostKeyChecking", "no");
			session.setConfig("PreferredAuthentications",
					"publickey,keyboard-interactive,password");

			UserInfo ui = new MyUserInfo() {
				public boolean promptYesNo(String str) {
					return false;
				}
			};
			session.setUserInfo(ui);
			session.connect();
			return session;
		} catch (Exception E) {
			E.printStackTrace();
		}
		return null;
	}

	/**
	 * User Information method
	 * 
	 * @author metro.MPandiaraj
	 *
	 */
	public static abstract class MyUserInfo implements UserInfo,
			UIKeyboardInteractive {
		public String getPassword() {
			return null;
		}

		public boolean promptYesNo(String str) {
			return false;
		}

		public String getPassphrase() {
			return null;
		}

		public boolean promptPassphrase(String message) {
			return false;
		}

		public boolean promptPassword(String message) {
			return false;
		}

		public void showMessage(String message) {
		}

		public String[] promptKeyboardInteractive(String destination,
				String name, String instruction, String[] prompt, boolean[] echo) {
			return null;
		}
	}

	/**
	 * Closes the parsed session
	 * 
	 * @param session
	 */
	public static void sessionClose(Session session) {
		session.disconnect();
	}

	/**
	 * Closes the parsed channel
	 * 
	 * @param session
	 */
	public static void closeChannel(Channel channel) {
		try {
			channel.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Generate random date and send in format yyyymmdd
	 * 
	 * @param i
	 * @return
	 */
	public static String randomDate(int i) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, i);
		calendar.set(Calendar.MONTH, randBetween(0, 11));
		calendar.set(Calendar.DAY_OF_YEAR, randBetween(1, 28));
		Date randomDoB = calendar.getTime();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String date = sdf.format(randomDoB);
		return date;
	}

	/**
	 * Returns current date in format yyyyMMdd-hhmmss
	 * 
	 * @return
	 */
	public static String currDate() {
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd-hhmmss");
		String date = sdf.format(calendar.getTime());
		return date;
	}

	/**
	 * Returns current date in format yyyyMMdd
	 * 
	 * @return
	 */
	public static String currDateyyyymmdd() {
		String date = ProjectConfig.getPropertyValue("sysdate");
		if (date.contains("local")){
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			date = sdf.format(calendar.getTime());	
		}
		return date;
	}

	/**
	 * Returns current date in format yyyyMMdd after adding corresponding dates
	 * 
	 * @return
	 * @throws ParseException 
	 */
	public static String currDateyyyymmddPlus(String daystoadd) throws ParseException {
		String date = ProjectConfig.getPropertyValue("sysdate");
		if (date.contains("local")){
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");			
			calendar.add(Calendar.DAY_OF_MONTH, Integer.parseInt(daystoadd));
			date = sdf.format(calendar.getTime());						
		}else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(sdf.parse(date));
			calendar.add(Calendar.DATE, Integer.parseInt(daystoadd));
			date = sdf.format(calendar.getTime());
		}
		return date;
	}

	// Returns Upcoming SUNDAY (WEEKEND) date in format yyyyMMdd
	public static String currDateyyyymmddweekend() throws ParseException {
		String date = ProjectConfig.getPropertyValue("sysdate");
		if (date.contains("local")){
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
			date = sdf.format(calendar.getTime());									
		}else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(sdf.parse(date));
			calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
			date = sdf.format(calendar.getTime());
		}		
		return date;
	}

	/**
	 * Random value in between 2 integers
	 * 
	 * @param start
	 * @param end
	 * @return
	 */
	private static int randBetween(int start, int end) {
		return start + (int) Math.round(Math.random() * (end - start));
	}

	/**
	 * Write the data into the file
	 * 
	 * @param writer
	 * @param ofsstring
	 * @param testcase
	 * @param customerResponse
	 */
	public static void writeToFile(PrintWriter writer, String ofsstring,
			String value, String testcase) {
		try {
			writer.println(testcase + "|" + ofsstring.trim() + "|"
					+ ofsstring.trim().split(",")[0] + "|"
					+ ofsstring.trim().split(",")[1] + "|" + value.trim());
		} catch (Exception e) {

		}
	}
}
