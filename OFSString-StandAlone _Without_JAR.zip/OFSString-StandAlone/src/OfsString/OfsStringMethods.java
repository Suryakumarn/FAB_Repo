package OfsString;

import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


















import org.apache.commons.lang3.RandomStringUtils;
//import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Level;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.Session;
import com.maveric.Data.DataProvider;
import com.maveric.DataHolder.FinalTestDataHolderClass;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.SkipException;

public class OfsStringMethods {

	//----Dynamic payment variables
	static int count_test= 0 ;
	static String dynamic= null ;
	static String[] testArray= new String[1000];
	static String SP_String = null;
	//----Dynamic payment variables
	
	static HashMap globalval = new HashMap();

	
	/**
	 * Establishes a channel Connection and wait for the appropriate response
	 * from the shell
	 * 
	 * @param session
	 * @return
	 */
	public static Channel establishChannelAsShell(Session session) {
		try {
			Channel channel = openChannelAsShell(session);
			

				expectInShell(channel,
						ProjectConfig.getPropertyValue("shellchar") + "*");
				sendCommand(channel,
						ProjectConfig.getPropertyValue("shelltemenos") + "\n",
						"GLOBUS");
				//pandi
				sendCommand(channel,
						ProjectConfig.getPropertyValue("sesspass") + "\n",
						"GLOBUS");
				//pandi
				sendCommand(channel, ProjectConfig.getPropertyValue("sesspass")
						+ "\n",
						ProjectConfig.getPropertyValue("shelltemenosexp"));
			
			String result = sendCommand(channel,
					ProjectConfig.getPropertyValue("shellt24cmd") + "\n",
					ProjectConfig.getPropertyValue("shellt24exp"));
			
			return channel;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static Channel establishDBAsShell(Session session) {
		try {
			Channel channel = openChannelAsShell(session);		

				expectInShell(channel,
						ProjectConfig.getPropertyValue("shellchar") + "*");				
				sendCommand(channel,
						ProjectConfig.getPropertyValue("shelltemenos") + "\n",
						"GLOBUS");
				//pandi
				sendCommand(channel,
						ProjectConfig.getPropertyValue("sesspass") + "\n",
						"GLOBUS");
				//pandi
				sendCommand(channel, ProjectConfig.getPropertyValue("sesspass")
						+ "\n",
						ProjectConfig.getPropertyValue("shelltemenosexp"));
			return channel;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static String expectInShell1(Channel channel, String expected) {
		try {
			Expect expect = new Expect(channel.getInputStream(),
					channel.getOutputStream());
			Pattern r = Pattern.compile(expected);
			expect.expect(r);
			if (expect.isSuccess) {
				String[] arr = expect.matchstring.split("\n");
				String finalres = "PASS|" + arr[arr.length - 1].trim();
				System.out.println("RETURNED ARRAY = " + finalres);
				return finalres;
			} else {
				String error = "FAIL|ERROR - ";
				try {
					error = error + expect.outputtempstr;
				} catch (Exception e) {

				}
				return error;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	
	private static String expectInShell(Channel channel, String expected) {
		try {
			
			
			Expect expect = new Expect(channel.getInputStream(),
					channel.getOutputStream());
			Pattern r = Pattern.compile(expected);
			expect.expect(r);
			if (expect.isSuccess) {
				String[] arr = expect.matchstring.split("\n");
				String finalres = "PASS|" + arr[arr.length - 1].trim();
				System.out.println("RETURNED ARRAY = " + finalres);
				return finalres;
			} else {
				String error = " ";
				try {
					error = error + expect.outputtempstr;
				} catch (Exception e) {

				}
				return error;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static String ofsConstructor(Entry<String, String> set,
			String ofsstring, String execution_mode) throws FilloException, ParseException {
		String replace = "";
		//KAK
		if (set.getKey().equalsIgnoreCase("DataBinding")
				|| set.getKey().equalsIgnoreCase("STRING-TYPE")|| set.getKey().equalsIgnoreCase("Expected Output")|| set.getKey().equalsIgnoreCase("AdditionalValidation")
				|| set.getKey().equalsIgnoreCase("Version") || set.getValue().equalsIgnoreCase("-")
				|| set.getKey().equalsIgnoreCase("User Group")||set.getKey().equalsIgnoreCase("Interface")||set.getKey().equalsIgnoreCase("Pre-requisite")
				|| set.getKey().equalsIgnoreCase("Functionality")|| set.getKey().equalsIgnoreCase("TestCase")||set.getKey().equalsIgnoreCase("OutputValue")
				|| set.getKey().equalsIgnoreCase("Business flow")||set.getKey().equalsIgnoreCase("Expected Result")
				|| set.getKey().equalsIgnoreCase("ITCR")||set.getKey().contains("be run with data")||set.getKey().equalsIgnoreCase("User Profile")
				|| set.getKey().equalsIgnoreCase("Transaction Type")||set.getKey().equalsIgnoreCase("MainFieldData")||set.getKey().equalsIgnoreCase("Business Rule")
				|| set.getKey().equalsIgnoreCase("Product")||set.getKey().equalsIgnoreCase("Product Category")||set.getKey().equalsIgnoreCase("Auth")) {
		} else {
			if (set.getKey().startsWith("IN.SWIFT.MSG")
					&& set.getKey().contains("~")) {
				replace = set.getKey().replace("~", "=");
				ofsstring = ofsstring + replace;
			} else
				ofsstring = ofsstring + set.getKey() + "=";

			int idx;
			String list = "";
			switch (set.getValue().split("~")[0]) {
			case "list":
				list = set.getValue().split("~")[1].trim();
				String[] lisarr = list.split(",");
				idx = new Random().nextInt(lisarr.length);
				String random = (lisarr[idx]);
				ofsstring = ofsstring + random;
				break;
			case "Str_AN":
                list = set.getValue().split("~")[1].trim();
                ofsstring = ofsstring
                            + "AN"+RandomStringUtils.random(Integer.parseInt(list),
                                        "0123456789");
              break;
			case "str":
				list = set.getValue().split("~")[1].trim();
				ofsstring = ofsstring
						+ RandomStringUtils.random(Integer.parseInt(list),
								"ABFERPLDBNVJK");
				break;
			case "ranstr":
				String fix = list = set.getValue().split("~")[1].trim();
				list = set.getValue().split("~")[2];
				ofsstring = ofsstring
						+ fix
						+ RandomStringUtils.random(Integer.parseInt(list) - 1,
								"ABFERPLDBNVJK");
				break;
			case "int":
				list = set.getValue().split("~")[1].trim();
				idx = new Random().nextInt(Integer.parseInt(list) - 1);
				ofsstring = ofsstring + idx;
				break;
			case "date":
				list = set.getValue().split("~")[1].trim();
				String date = "";
				if (list.equalsIgnoreCase("current"))
					date = CommonDef.currDateyyyymmdd();
				else if (list.startsWith("current+"))
					date = CommonDef.currDateyyyymmddPlus(list.split("\\+")[1]);
				else if (list.startsWith("current-"))
					date = CommonDef.currDateyyyymmddPlus("-"+list.split("\\-")[1]);
				else if (list.startsWith("weekend"))
					date = CommonDef.currDateyyyymmddweekend();
				else
					date = CommonDef.randomDate(1990);
				try {
					String addstr = set.getValue().split("~")[2].trim();
					if (addstr.startsWith("add")) {
						addstr.split("-");
						date = date + addstr.split("-")[1];
					}
				} catch (Exception e) {

				}
				try {
					date = CommonDef.randomDate(1990 + Integer.parseInt(set
							.getValue().split("~")[2]));
				} catch (Exception e) {

				}
				ofsstring = ofsstring + date;
				break;
		
			case "Blank":
				list = "";
				ofsstring = ofsstring + list;
				break;
			case "fetch":
				String fetchid = set.getValue().split("~")[1].trim();				
				if(execution_mode.equalsIgnoreCase("ExtractedData")){
					String[] str_FileAndSheetName =  ExcelReader.fetchFileAndSheetName(OfsStringReader.init(),fetchid);					
					list = ExcelReader.fetchoutput_DataBase(str_FileAndSheetName[0],str_FileAndSheetName[1]);
				}else{
				list = ExcelReader.fetchoutput(OfsStringReader.init(),fetchid);
				}
				ofsstring = ofsstring + list;
				System.out.println("Fetch = "+ofsstring);
				break;
			case "freq":
                list = set.getValue().split("~")[1].trim();
                String freq = "";
                if (list.equalsIgnoreCase("current"))
                      freq = CommonDef.currDateyyyymmdd();
                else if (list.startsWith("current+"))
                      freq = CommonDef.currDateyyyymmddPlus(list.split("\\+")[1]);
                else if (list.startsWith("current-"))
                      freq = CommonDef.currDateyyyymmddPlus("-"+list.split("\\-")[1]);
                else if (list.startsWith("weekend"))
                      freq = CommonDef.currDateyyyymmddweekend();
                else{
                      freq = CommonDef.randomDate(1990);
                }
                ofsstring = ofsstring + freq + " " + set.getValue().split("~")[2].trim();
                break;
			default:
				//System.out.println(set.getValue());
				list = set.getValue().split("~")[1].trim();
				ofsstring = ofsstring + list;
				break;
			}
			if (!replace.isEmpty())
				ofsstring = ofsstring + "\"" + ",";
			else
				ofsstring = ofsstring + ",";
		}
		return ofsstring;
	}

	public static String sendCommand(Channel channel, String keystosend,
			String responsevalidator) {
		try {
			Expect expect = new Expect(channel.getInputStream(),
					channel.getOutputStream());
			expect.send(keystosend);
			
			return expectInShell(channel, responsevalidator);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static Channel openChannelAsShell(Session session) {
		try {
			Channel channel = session.openChannel("shell");
			channel.connect();
			Expect.addLogToConsole(Level.ALL);
			return channel;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}	

	private static String getPass(LinkedHashMap<String, String> singleentry,
			String user) {
		String password;
		password = ProjectConfig.getPropertyValue("pass");
		try {
			if (singleentry.get("user").equals(user))
				password = singleentry.get("password");
			else
				password = ProjectConfig.getPropertyValue("pass");
		} catch (Exception e) {
		}
		return password;
	}

	private static String getUser(LinkedHashMap<String, String> singleentry) {
		String user = ProjectConfig.getPropertyValue("user");
		try {
			if (singleentry.get("user").length() > 1) {
				user = singleentry.get("user");
			}
		} catch (Exception e) {
		}
		return user;
	}

	public static String getCustomerID(String customerResponse, String custmatch) {
		Pattern r = Pattern.compile(custmatch);
		Matcher m = r.matcher(customerResponse);
		if (m.find()) {
			System.out.println(m.group(0));
			String test1 = m.group(0).replace("\n", "");
			return test1.split("/")[0];
		
			/*if (singleentry.get("Business flow").equalsIgnoreCase("Positive")){
				
				if (customerResponse.contains("/-1")){
					ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Fail","Not able to create the Account number",singleentry.get("Business flow"),Dtime);
				}else{
					
					if (output[0].toString().contains("PASS")){
						ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Pass",output[0].substring(5,output[0].length()),singleentry.get("Business flow"),Dtime);
					}else{
						ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Fail","Not able to create the Account number",singleentry.get("Business flow"),Dtime);
					}
					
				}
			}else{
				if (customerResponse.contains("/-1")){
					ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Pass",output[3].substring(0,output[0].length()),singleentry.get("Business flow"),Dtime);
				}else{
					ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Fail","Account is being created in the negative scenario",singleentry.get("Business flow"),Dtime);
				}
			}*/
			
		} else
			return null;
	}
	
	public static String data_enquiry(Channel channel, String testcase,
			String runConfig, 
			PrintWriter writer,String sheet_id,Session sshsession) {
		try {
			ArrayList<LinkedHashMap<String, String>> account = ExcelReader
					.readDataFormat(testcase, runConfig, sheet_id);
			String customerResponse;
			String Transmatch = ProjectConfig.getPropertyValue("custmatch_pos");
			
			for (LinkedHashMap<String, String> singleentry : account) {
				String ofsstring = "LIST FBNK.ACCOUNT WITH CATEGORY EQ 1020 CUSTOMER.NO";
				customerResponse = OfsStringMethods.sendCommand(channel,
						ofsstring + "\n", Transmatch);
				String ct [] = customerResponse.trim().split(" ");
				System.out.println("Output " + customerResponse); 
			}
		
		}
	///return customerResponse;
	 catch (Exception e) {
		e.printStackTrace();
	}
	return null;
	}
	
	
	public static String create_Account(Channel channel, String testcase,String runConfig,
			String sheet_id,Session sshsession,String execution_mode) {
		try {
			ArrayList<LinkedHashMap<String, String>> account = ExcelReader
					.readDataFormat(testcase, runConfig, sheet_id);
			String accounts = "";
			String accno = null;
			String customerID = null;
			//Boolean sessionConnection = true;
			for (LinkedHashMap<String, String> singleentry : account) {
				
				/*if(!(sessionConnection)){					
					sshsession = CommonDef.sessionOpen();
					sshsession.setTimeout(100);
					channel = OfsStringMethods.establishChannelAsShell(sshsession);
				}*/
				
				String stdate[] = CommonDef.currDate().split("-");
				String Dtime = stdate[1].substring(0,2)+":"+stdate[1].substring(2,4)+":"+stdate[1].substring(4,6);
				String ofsstring = "";
				
				String extracted_value = "";
				String dapuser = ProjectConfig.getPropertyValue("dapuser");
				String dappswd = ProjectConfig.getPropertyValue("dappass"); 
				String sjpuser = ProjectConfig.getPropertyValue("sjpuser");
				String sjppass = ProjectConfig.getPropertyValue("sjppass");
				String dapbranchcode = ProjectConfig.getPropertyValue("dapbranchcode");
				String cashierbranchcode = ProjectConfig.getPropertyValue("cashierbranchcode");
				String user = ProjectConfig.getPropertyValue("user");
				String pass = ProjectConfig.getPropertyValue("pass");
				
				globalval.put("Functionality",singleentry.get("Functionality"));
				globalval.put("TestCase",singleentry.get("TestCase"));
				globalval.put("CaseDesc",singleentry.get("Business Rule"));
				 String fetchid = null;
				 String dt = null;
				//Enquiry String 
				if(singleentry.get("DataBinding").contains("New")){
				  //ENQUIRY.SELECT,,AUTOUSER02/India@123,METR.FP.DETAILS.ENQ,FT.ID:EQ=FT163653T97V 
				   ofsstring = ofsstring 
					 + "ENQUIRY.SELECT" + "," + ","+ user + "/" + pass + ","+singleentry.get("Version")+",";
				}else if(singleentry.get("DataBinding").contains("DAP")){
					ofsstring = ofsstring 
							+ singleentry.get("Version") + "/I/PROCESS//0" + ","
							+ user + "/" + pass  + "/" + dapbranchcode + ","+ ",";
				}else if(singleentry.get("DataBinding").contains("SJP")){
                    ofsstring = ofsstring 
                            + singleentry.get("Version") + "/I/PROCESS//0" + ","
                            + sjpuser + "/" + sjppass  + ","+ ",";
				}else if(singleentry.get("DataBinding").contains("USE")){
					ofsstring = ofsstring 
							+ singleentry.get("Version") + "/I/PROCESS//0" + ","
							+ user + "/" + pass  + "/" + ProjectConfig.getPropertyValue("usembassybcode") + ","+ ",";
				}else if(singleentry.get("DataBinding").contains("MMA")){
					ofsstring = ofsstring 
							+ singleentry.get("Version") + "/I/PROCESS//0" + ","
							+ ProjectConfig.getPropertyValue("mmauser") + "/" + ProjectConfig.getPropertyValue("mmapass")  + ","+ ",";
				}else if(singleentry.get("DataBinding").contains("ISA")){
					if (sheet_id.equals("Cash_Deposit")){
						ofsstring = ofsstring 
								+ singleentry.get("Version") + "/I/PROCESS//0" + ","
								+ user + "/" + pass + "," + ",";
				}else{
					ofsstring = ofsstring 
							+ singleentry.get("Version") + "/I/PROCESS//0" + ","
							+ ProjectConfig.getPropertyValue("isauser") + "/" + ProjectConfig.getPropertyValue("isapass")  + ","+ ",";
				}
				}
				else{					
					 if(singleentry.containsKey("MainFieldData")){
						 if(singleentry.containsKey("Auth")&&singleentry.get("Auth").equalsIgnoreCase("A")) {
								fetchid = singleentry.get("MainFieldData").split("~")[1].trim();
								 dt = ExcelReader.fetchoutput(OfsStringReader.init(),fetchid);
								ofsstring = ofsstring
		                                + singleentry.get("Version") + "/A/PROCESS//0" + ","
		                                + user + "/" + pass + "," + dt + ",";
		                        }
		                    else if(singleentry.containsKey("Auth")&&singleentry.get("Auth").equalsIgnoreCase("D")) {
		                    	fetchid = singleentry.get("MainFieldData").split("~")[1].trim();
		   					 dt = ExcelReader.fetchoutput(OfsStringReader.init(),fetchid);    
		                    	ofsstring = ofsstring
		                                    + singleentry.get("Version") + "/D/PROCESS//0" + ","
		                                    + user + "/" + pass + "," + dt + ",";
		                            }
						 if (singleentry.get("MainFieldData").contains("text")){
							 ofsstring = ofsstring 
										+ singleentry.get("Version") + "/I/PROCESS//0" + ","
										+ user + "/" + pass+ "," +singleentry.get("MainFieldData").split("~")[1].trim()+ ",";
						 }else if(singleentry.get("MainFieldData").contains("fetch")){
							  fetchid = singleentry.get("MainFieldData").split("~")[1].trim();
							    if(execution_mode.equalsIgnoreCase("ExtractedData")){
									String[] str_FileAndSheetName = ExcelReader.fetchFileAndSheetName(OfsStringReader.init(),fetchid);
								    dt = ExcelReader.fetchoutput_DataBase(str_FileAndSheetName[0],str_FileAndSheetName[1]);
								    extracted_value = dt;
						        }else{
								 dt = ExcelReader.fetchoutput(OfsStringReader.init(),fetchid);
						        }
								ofsstring = ofsstring 
										+ singleentry.get("Version") + "/I/PROCESS//0" + ","
										+ user + "/" + pass + "," +dt+ ",";
						 }else if(singleentry.get("MainFieldData").contains("-")){
							 ofsstring = ofsstring 
										+ singleentry.get("Version") + "/I/PROCESS//0" + ","
										+ user + "/" + pass + "," + ",";
						 }
					}else if (singleentry.get("Version").contains("TELLER")){
						ofsstring = ofsstring 
								+ singleentry.get("Version") + "/I/PROCESS//0" + ","
								+ user + "/" + getPass(singleentry, user) + "/" + cashierbranchcode + ","+ ",";
					}else{
					ofsstring = ofsstring 
							+ singleentry.get("Version") + "/I/PROCESS//0" + ","
							+ user + "/" + pass + "," + ",";
					}
					
				}				
				int i = 0;
				for (Entry<String, String> set : singleentry.entrySet()) {					
					String tmp = ofsstring;					
					ofsstring = ofsConstructor(set, ofsstring, execution_mode);
					if ((set.getValue().split("~")[0].equalsIgnoreCase("fetch"))&&(execution_mode.equalsIgnoreCase("ExtractedData"))){
						extracted_value = ofsstring.split(tmp)[1];
						extracted_value = extracted_value.split("=")[1];
						extracted_value = extracted_value.split(",")[0];
					}					
				}
				String Transmatch = null;
				ofsstring = ofsstring.substring(0, ofsstring.length() - 1);				
				String customerResponse;				
				// Regular Expression for matching output
				if(singleentry.get("Business flow").equals("Positive")){
					if (sheet_id.contains("Treasury")){
						if(sheet_id.contains("Treasury_Forward")||sheet_id.contains("TreasurySpot")){
							Transmatch = ProjectConfig.getPropertyValue("fxmatch_pos");
						}else{
							Transmatch = ProjectConfig.getPropertyValue("ftdmatch_pos");
						}
							
					}else if(sheet_id.contains("FTD")){
						Transmatch = ProjectConfig.getPropertyValue("ftdmatch_pos");
					}else if(sheet_id.contains("ISA_FUND")|| sheet_id.contains("OutgoingPayments")
							||sheet_id.contains("MiscellaneousSWIFT")||sheet_id.contains("SEPA-Payments")
							||sheet_id.contains("Swift103Serial")||sheet_id.contains("Faster_Payments")){
						Transmatch = ProjectConfig.getPropertyValue("fpmatch_pos");
					}else if(sheet_id.contains("Standing-Order")||sheet_id.contains("SWIFT_Standing-Order")){
						Transmatch = ProjectConfig.getPropertyValue("somatch_pos");	
					}else if(sheet_id.contains("FP")){
						Transmatch = ProjectConfig.getPropertyValue("Enquiry");	
					}else if(sheet_id.contains("Cash_Deposit")){
						Transmatch = ProjectConfig.getPropertyValue("ttmatch_pos");
					}else if(sheet_id.contains("ChapsPayment")){
						Transmatch = ProjectConfig.getPropertyValue("fpmatch_pos");
					}else{
						Transmatch = ProjectConfig.getPropertyValue("custmatch_pos");
					}
				}else if (singleentry.get("Business flow").equals("Negative")){
					if (sheet_id.contains("Treasury")){
						if(sheet_id.contains("Treasury_Forward")||sheet_id.contains("TreasurySpot")){
							Transmatch = ProjectConfig.getPropertyValue("fxmatch_neg");
						}else{
							Transmatch = ProjectConfig.getPropertyValue("ftdmatch_neg");
						}	
					}else if(sheet_id.contains("FTD")){
						Transmatch = ProjectConfig.getPropertyValue("ftdmatch_neg");
					}else if(sheet_id.contains("ISA_FUND")|| sheet_id.contains("OutgoingPayments")
							||sheet_id.contains("MiscellaneousSWIFT")||sheet_id.contains("SEPA-Payments")
							||sheet_id.contains("Swift103Serial")){
						Transmatch = ProjectConfig.getPropertyValue("fpmatch_neg");
					}else if(sheet_id.contains("Standing-Order")||sheet_id.contains("SWIFT_Standing-Order")){
						Transmatch = ProjectConfig.getPropertyValue("somatch_neg");	
					}else if(sheet_id.contains("Cash_Deposit")){
						Transmatch = ProjectConfig.getPropertyValue("ttmatch_neg");
					}else if(sheet_id.contains("ChapsPayment")){
						Transmatch = ProjectConfig.getPropertyValue("fpmatch_neg");
					}else{
						Transmatch = ProjectConfig.getPropertyValue("custmatch_neg");
					}
				}
				//----------------------
				// Dynamic input flow Starts
				if(ofsstring.contains("Combination")){
					String outputFile = System.getProperty("user.dir")+"//outputfile//dynamicInput.xlsx";
					File f = new File(outputFile);					
					if (!(f.exists())){
						ExcelReader.Write_input(outputFile,"output");
					}					
					String[] ofsstring_sp = ofsstring.split("Combination");
					String[] ofsstring_sp_c= ofsstring_sp[1].split(",");
					SP_String = "Combination"+ofsstring_sp_c[0];
					ArrayList<LinkedHashMap<String, String>> outputSet = ExcelReader.readOutputSheet(outputFile,SP_String);
					int c = -1;
					for(LinkedHashMap<String, String> outputvalue : outputSet){
						c = c+1;
						if(outputvalue.get("Value").length()<1){
							testArray[c]= outputvalue.get("Positve/Negative")+"DataComb"+" ";
						}else{
						  testArray[c]=outputvalue.get("Positve/Negative")+"DataComb"+outputvalue.get("Value");
						}
					}
					count_test = c;
				}else{
					count_test = 0;
				}

			    for (int test=0;test<=count_test;test ++){
				  String ofsstring1 = null;
			      if(ofsstring.contains("Combination")){
			         String[] ofsstring_sp = ofsstring.split(SP_String);			         
			         String[] sp_data = testArray[test].split("DataComb");
			         System.out.println("Dynamically fetched data => \"" + sp_data[1].trim()+"\"");
			         String Business_flow ;

			         if(sp_data[0].contains("Positive")){
				       Business_flow = "Positive";
			         }else {
				       Business_flow = "Negative";
			         }				
			        singleentry.put("Business flow",Business_flow);
			        ofsstring1 =ofsstring_sp[0]+sp_data[1].trim()+ofsstring_sp[1];
			      }else{
				    ofsstring1 = ofsstring;
			      }
			    
				// Dynamic input flow Ends
				//------------------------
 		        System.out.println("OFS : " + ofsstring1);
				customerResponse = OfsStringMethods.sendCommand(channel,ofsstring1 + "\n", Transmatch);
				System.out.println(customerResponse);

				if (customerResponse.equals("FAIL|ERROR - null")){
					ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Fail","FAIL|ERROR - null","System Timeout Issue",singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), "FAIL|ERROR - null");
					throw new SkipException("Environment is down");
				}else {
					if(sheet_id.contains("Treasury_REPODeposit")){
						String op[] = customerResponse.split("MM");
						customerResponse = "PASS-MM" + op[3];
					}
					String status[] = null;
					String output[]=customerResponse.split("/");
					customerID = output[0].substring(5,output[0].length());					
					//-----------------------------------------------------------
					//KAK
					Boolean addVerification = false;
					if(singleentry.containsKey("AdditionalValidation")){
						if(singleentry.get("AdditionalValidation").contains(",")){
						  String[] AVL = (singleentry.get("AdditionalValidation")).split(",");
						  for(int loop = 0;loop<=AVL.length-1;loop++){
							  if(customerResponse.contains(AVL[loop])){
								  addVerification = true;
							  }else{
								  addVerification = false;
								  break;
							  }
						  }	
						}else{
						  if(customerResponse.contains(singleentry.get("AdditionalValidation"))){
							  addVerification = true;
						  }else{
							  addVerification = false;
						  }
						}
					}else{
					  addVerification = true;
					}
					//KAK
					//-----------------------------------------------------------
					// Condition to not validate the Exact output values begin 
					/*if (singleentry.get("Business flow").equalsIgnoreCase("Positive")){
		
						if (customerResponse.contains("/-1")){
							String sp[]= customerResponse.split("-1");
							ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",customerID,sp[1].substring(4, sp[1].length()),singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
							ExtentReport.Write_Result(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",customerID,sp[1].substring(4, sp[1].length()),singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
						}else{
							if ((output[0].toString().contains("PASS"))&& addVerification ){
								ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Pass",customerID,singleentry.get("Functionality")+" is successful",singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
								ExtentReport.Write_Result(ExcelReader.g_globalval.get("Result_File").toString(),"Pass",customerID,singleentry.get("Functionality")+" is successful",singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
							}else{
								ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",customerID,singleentry.get("Functionality")+" is not successful",singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
								ExtentReport.Write_Result(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",customerID,singleentry.get("Functionality")+" is not successful",singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
							}
						}
					}else{
						(if (customerResponse.contains("/-1"))&& addVerification ){
							String sp[]= customerResponse.split("-1");
							ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Pass",customerID,sp[1].substring(4, sp[1].length()),singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
							ExtentReport.Write_Result(ExcelReader.g_globalval.get("Result_File").toString(),"Pass",customerID,sp[1].substring(4, sp[1].length()),singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
						}else{
							ExcelReader.Write_Reult(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",customerID,singleentry.get("Functionality")+" is successful",singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
							ExtentReport.Write_Result(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",customerID,singleentry.get("Functionality")+" is successful",singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
						}
					}*/
					// Condition to not validate the Exact output values ends
					//-----------------------------------------------------------
					// Condition to validate the Exact output values begin		
/*					if(output.length==1){
						System.out.println("Server Response issue");
						ExcelReader.Write_Reultnew(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",customerID,singleentry.get("Functionality"),singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[0],singleentry.get("Expected Output"));						
						CommonDef.sessionClose(sshsession);
						sessionConnection = false;						
						break;
					}else{*/
					if (singleentry.get("Business flow").equalsIgnoreCase("Positive")){

						if (customerResponse.contains("/-1")){
							String sp[]= customerResponse.split("-1");
							ExcelReader.Write_Reultnew(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",customerID,sp[1],singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1],singleentry.get("Expected Output"));
							ExtentReport.Write_Result(ExcelReader.g_globalval.get("Result_File").toString() , "Fail" , customerID , singleentry.get("Functionality")+" is not successful" , singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
							
						}else{
							if ((output[0].toString().contains("PASS")) && addVerification ){
								if(execution_mode.equalsIgnoreCase("ExtractedData")){
									ExcelReader.update_extracted_output(extracted_value,ExcelReader.g_globalval.get("ExtractedFileName").toString(),ExcelReader.g_globalval.get("ExtractedSheetName").toString());
						        }
								ExcelReader.Write_Reultnew(ExcelReader.g_globalval.get("Result_File").toString(),"Pass",customerID,singleentry.get("Functionality")+" is successful",singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1],singleentry.get("Expected Output"));
								ExtentReport.Write_Result(ExcelReader.g_globalval.get("Result_File").toString() , "Pass" , customerID , singleentry.get("Functionality")+" is successful" , singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
								
							}else{
								ExcelReader.Write_Reultnew(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",customerID,singleentry.get("Functionality")+" is not sucessful",singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1],singleentry.get("Expected Output"));
								ExtentReport.Write_Result(ExcelReader.g_globalval.get("Result_File").toString() , "Fail" , customerID , singleentry.get("Functionality")+" is not successful" , singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
								
							}
						}
					}else{						
						if (customerResponse.contains("/-1")){
							String sp[]= customerResponse.split("-1");
							if ((sp[1].substring(4, sp[1].length()).equalsIgnoreCase(singleentry.get("Expected Output"))) && addVerification ){
								if(execution_mode.equalsIgnoreCase("ExtractedData")){
									ExcelReader.update_extracted_output(extracted_value,ExcelReader.g_globalval.get("ExtractedFileName").toString(),ExcelReader.g_globalval.get("ExtractedSheetName").toString());
						        }
								ExcelReader.Write_Reultnew(ExcelReader.g_globalval.get("Result_File").toString(),"Pass",customerID,sp[1].substring(4, sp[1].length()),singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1],singleentry.get("Expected Output"));
								ExtentReport.Write_Result(ExcelReader.g_globalval.get("Result_File").toString() ,"Pass", customerID ,sp[1].substring(4, sp[1].length()), singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
							}else{
								ExcelReader.Write_Reultnew(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",customerID,"Error occured but not matching with expected - " + sp[1].substring(4, sp[1].length()),singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1],singleentry.get("Expected Output"));
								ExtentReport.Write_Result(ExcelReader.g_globalval.get("Result_File").toString() , "Fail" , customerID , "Error occured but not matching with expected - " + sp[1].substring(4, sp[1].length()),singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
							}
						}else{
							ExcelReader.Write_Reultnew(ExcelReader.g_globalval.get("Result_File").toString(),"Fail",customerID,singleentry.get("Functionality")+" is successful",singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1],singleentry.get("Expected Output"));
							ExtentReport.Write_Result(ExcelReader.g_globalval.get("Result_File").toString() , "Fail" , customerID , singleentry.get("Functionality")+" is successful" , singleentry.get("Business flow"),Dtime,singleentry.get("Expected Result"),singleentry.get("Business Rule"), output[1]);
						}
					}
					//}
					// Condition to validate the Exact output values ends
					//-----------------------------------------------------------
						if (singleentry.containsKey("OutputValue") && !singleentry.get("OutputValue").equals("")){
							ExcelReader.storeoutput(OfsStringReader.init(), singleentry.get("OutputValue"), customerID, output[1]);
						}
					}
				}
			}
			return accno;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
}