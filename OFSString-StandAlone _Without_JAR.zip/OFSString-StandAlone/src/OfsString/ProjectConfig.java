package OfsString;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class ProjectConfig {
	public static Properties prop = new Properties();
	public static String filepath;
	static {
		try {
			filepath = System.getProperty("ResSuite");
			System.out.println("FILE PATH "  + filepath);
			if (filepath == null) {
				filepath = OfsStringReader.propertyfile;
				System.out.println("FILE PATH 2"  + filepath);
				try{
					InputStream resourceStream = Thread.currentThread().getContextClassLoader()
							.getResourceAsStream(filepath);
					//prop.load(resourceStream);
					prop.load(new FileInputStream(filepath));
				} catch (Exception E) {
					
				}
			} else {
				System.out.println(filepath);
				filepath = filepath + "/" + "projectconfig.properties";
				prop.load(new FileInputStream(filepath));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String getPropertyValue(String key) {
		return prop.getProperty(key);
	}
	
	public static void setPropertyValue(String key,String val) {
		 prop.getProperty(key,val);
	}
}
